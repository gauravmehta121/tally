from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from .models import CustomUser

class SignUpForm(UserCreationForm):
    referral_code = forms.CharField(required=False)

    class Meta:
        model = CustomUser
        fields = ('first_name', 'last_name', 'email', 'password1', 'password2', 'referral_code')

    def clean_referral_code(self):
        referral_code = self.cleaned_data.get('referral_code')
        if referral_code:
            try:
                CustomUser.objects.get(referral_code=referral_code)
            except CustomUser.DoesNotExist:
                raise forms.ValidationError('Invalid referral code')
        return referral_code

    def save(self, commit=True):
        user = super().save(commit=False)
        user.referral_code = self.cleaned_data.get('referral_code')
        if commit:
            user.save()
        return user

class LoginForm(AuthenticationForm):
    pass
